/**
* Config JS file for Poveglia
*/

var config = {
    'share-selected-text': true,
    'load-more': true,
    'infinite-scroll': false,
    'infinite-scroll-step': 1,
    'disqus-shortname': 'hauntedthemes-demo',
    'content-api-host': '',
    'content-api-key': '',
};
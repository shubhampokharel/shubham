Poveglia - Multipurpose Ghost Theme by Haunted Themes
============================

> Copyright (C) HauntedThemes SRL
> https://www.hauntedthemes.com

This theme is available as part of the HauntedThemes.com membership. 
The membership provides access to important theme updates and tech support, as well as the rest of our awesome Ghost Themes.

All themes are released under the GNU Public License version 2.0.

https://www.hauntedthemes.com/terms-of-service/
https://www.hauntedthemes.com/privacy-policy/